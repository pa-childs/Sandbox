#!/usr/bin/python3
__author__ = 'kilroy'
#  (c) 2014, WasHere Consulting, Inc.
#  Written for Infinite Skills

import socket

print(socket.gethostbyaddr("8.8.8.8"))
print(socket.gethostbyname("www.google.com"))
